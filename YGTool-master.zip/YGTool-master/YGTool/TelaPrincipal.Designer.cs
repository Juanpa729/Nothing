﻿namespace YGTool
{
    partial class TelaPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaPrincipal));
            this.arquivosTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.tagForceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eHPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportarÚnicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportarDePastaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarÚnicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarEmLoteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bootbinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tARGFORCE2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportarEhpsNoEBBOTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarEhpsNoEBOOTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportarGIMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarGimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sndDatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tagForce4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.europeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.japanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tagToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jpanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarPacotesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sPSoundPackageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ùnicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sPRenamerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lBARecalcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textoTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.tagForceToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.extrairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poneirosInternosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.únicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emLoteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ponteirosInternosDiretosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.únicoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.loteeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ponteirosExternosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.únicoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.dLGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ponteirosTipo4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.packstrExplainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cardInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.únicoToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.pastaCardinfoTag4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pastaCardinfoTag6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarTextosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previewTagForceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cardSortEditorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imagensTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.tagForceToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.únicoToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.emLoteDePastaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.únicoToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.emLoteDePastaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ediToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.compressãoTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.gzipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gZIPToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.descomprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.únicoToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.emLoteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.comprimirToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.únicoToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.emLoteToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.progressBarGimConv = new System.Windows.Forms.ProgressBar();
            this.labelGimComv = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // arquivosTSM
            // 
            this.arquivosTSM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tagForceToolStripMenuItem});
            this.arquivosTSM.Name = "arquivosTSM";
            this.arquivosTSM.Size = new System.Drawing.Size(66, 20);
            this.arquivosTSM.Text = "Arquivos";
            // 
            // tagForceToolStripMenuItem
            // 
            this.tagForceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eHPToolStripMenuItem,
            this.bootbinToolStripMenuItem,
            this.cipToolStripMenuItem,
            this.sndDatToolStripMenuItem,
            this.sPSoundPackageToolStripMenuItem,
            this.lBARecalcToolStripMenuItem});
            this.tagForceToolStripMenuItem.Name = "tagForceToolStripMenuItem";
            this.tagForceToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tagForceToolStripMenuItem.Text = "Tag Force";
            // 
            // eHPToolStripMenuItem
            // 
            this.eHPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportarÚnicoToolStripMenuItem,
            this.exportarDePastaToolStripMenuItem,
            this.importarÚnicoToolStripMenuItem,
            this.importarEmLoteToolStripMenuItem});
            this.eHPToolStripMenuItem.Name = "eHPToolStripMenuItem";
            this.eHPToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.eHPToolStripMenuItem.Text = "Ehp";
            // 
            // exportarÚnicoToolStripMenuItem
            // 
            this.exportarÚnicoToolStripMenuItem.Name = "exportarÚnicoToolStripMenuItem";
            this.exportarÚnicoToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.exportarÚnicoToolStripMenuItem.Text = "Exportar único";
            this.exportarÚnicoToolStripMenuItem.Click += new System.EventHandler(this.exportarÚnicoToolStripMenuItem_Click);
            // 
            // exportarDePastaToolStripMenuItem
            // 
            this.exportarDePastaToolStripMenuItem.Name = "exportarDePastaToolStripMenuItem";
            this.exportarDePastaToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.exportarDePastaToolStripMenuItem.Text = "Em Lote";
            this.exportarDePastaToolStripMenuItem.Click += new System.EventHandler(this.exportarDePastaToolStripMenuItem_Click);
            // 
            // importarÚnicoToolStripMenuItem
            // 
            this.importarÚnicoToolStripMenuItem.Name = "importarÚnicoToolStripMenuItem";
            this.importarÚnicoToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.importarÚnicoToolStripMenuItem.Text = "Importar Único";
            this.importarÚnicoToolStripMenuItem.Click += new System.EventHandler(this.importarÚnicoToolStripMenuItem_Click);
            // 
            // importarEmLoteToolStripMenuItem
            // 
            this.importarEmLoteToolStripMenuItem.Name = "importarEmLoteToolStripMenuItem";
            this.importarEmLoteToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.importarEmLoteToolStripMenuItem.Text = "Importar Em Lote";
            this.importarEmLoteToolStripMenuItem.Click += new System.EventHandler(this.importarEmLoteToolStripMenuItem_Click);
            // 
            // bootbinToolStripMenuItem
            // 
            this.bootbinToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tARGFORCE2ToolStripMenuItem});
            this.bootbinToolStripMenuItem.Name = "bootbinToolStripMenuItem";
            this.bootbinToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.bootbinToolStripMenuItem.Text = "EBOOT.BIN";
            // 
            // tARGFORCE2ToolStripMenuItem
            // 
            this.tARGFORCE2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportarEhpsNoEBBOTToolStripMenuItem,
            this.importarEhpsNoEBOOTToolStripMenuItem});
            this.tARGFORCE2ToolStripMenuItem.Name = "tARGFORCE2ToolStripMenuItem";
            this.tARGFORCE2ToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.tARGFORCE2ToolStripMenuItem.Text = "Tag Force 2/3/4/5/6/ARC V";
            // 
            // exportarEhpsNoEBBOTToolStripMenuItem
            // 
            this.exportarEhpsNoEBBOTToolStripMenuItem.Name = "exportarEhpsNoEBBOTToolStripMenuItem";
            this.exportarEhpsNoEBBOTToolStripMenuItem.Size = new System.Drawing.Size(260, 22);
            this.exportarEhpsNoEBBOTToolStripMenuItem.Text = "Exportar ehps no EBOOT";
            this.exportarEhpsNoEBBOTToolStripMenuItem.Click += new System.EventHandler(this.exportarEhpsNoEBBOTToolStripMenuItem_Click);
            // 
            // importarEhpsNoEBOOTToolStripMenuItem
            // 
            this.importarEhpsNoEBOOTToolStripMenuItem.Name = "importarEhpsNoEBOOTToolStripMenuItem";
            this.importarEhpsNoEBOOTToolStripMenuItem.Size = new System.Drawing.Size(260, 22);
            this.importarEhpsNoEBOOTToolStripMenuItem.Text = "Importar ehps com texto ao EBOOT";
            this.importarEhpsNoEBOOTToolStripMenuItem.Click += new System.EventHandler(this.importarEhpsNoEBOOTToolStripMenuItem_Click);
            // 
            // cipToolStripMenuItem
            // 
            this.cipToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportarGIMToolStripMenuItem,
            this.importarGimToolStripMenuItem});
            this.cipToolStripMenuItem.Name = "cipToolStripMenuItem";
            this.cipToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.cipToolStripMenuItem.Text = "Card_h";
            // 
            // exportarGIMToolStripMenuItem
            // 
            this.exportarGIMToolStripMenuItem.Name = "exportarGIMToolStripMenuItem";
            this.exportarGIMToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.exportarGIMToolStripMenuItem.Text = "Procura e Exportar Gims";
            this.exportarGIMToolStripMenuItem.Click += new System.EventHandler(this.exportarGIMToolStripMenuItem_Click);
            // 
            // importarGimToolStripMenuItem
            // 
            this.importarGimToolStripMenuItem.Name = "importarGimToolStripMenuItem";
            this.importarGimToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.importarGimToolStripMenuItem.Text = "Importar Gims";
            this.importarGimToolStripMenuItem.Click += new System.EventHandler(this.importarGimToolStripMenuItem_Click);
            // 
            // sndDatToolStripMenuItem
            // 
            this.sndDatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportarToolStripMenuItem1,
            this.importarPacotesToolStripMenuItem});
            this.sndDatToolStripMenuItem.Enabled = false;
            this.sndDatToolStripMenuItem.Name = "sndDatToolStripMenuItem";
            this.sndDatToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.sndDatToolStripMenuItem.Text = "SndDat";
            this.sndDatToolStripMenuItem.Visible = false;
            // 
            // exportarToolStripMenuItem1
            // 
            this.exportarToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tagForce4ToolStripMenuItem,
            this.tagToolStripMenuItem});
            this.exportarToolStripMenuItem1.Name = "exportarToolStripMenuItem1";
            this.exportarToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.exportarToolStripMenuItem1.Text = "Exportar pacotes";
            // 
            // tagForce4ToolStripMenuItem
            // 
            this.tagForce4ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.europeToolStripMenuItem,
            this.japanToolStripMenuItem});
            this.tagForce4ToolStripMenuItem.Name = "tagForce4ToolStripMenuItem";
            this.tagForce4ToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.tagForce4ToolStripMenuItem.Text = "Tag Force 3";
            // 
            // europeToolStripMenuItem
            // 
            this.europeToolStripMenuItem.Name = "europeToolStripMenuItem";
            this.europeToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.europeToolStripMenuItem.Text = "Europe";
            this.europeToolStripMenuItem.Click += new System.EventHandler(this.europeToolStripMenuItem_Click);
            // 
            // japanToolStripMenuItem
            // 
            this.japanToolStripMenuItem.Name = "japanToolStripMenuItem";
            this.japanToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.japanToolStripMenuItem.Text = "Japan";
            this.japanToolStripMenuItem.Click += new System.EventHandler(this.japanToolStripMenuItem_Click);
            // 
            // tagToolStripMenuItem
            // 
            this.tagToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uSAToolStripMenuItem,
            this.jpanToolStripMenuItem});
            this.tagToolStripMenuItem.Name = "tagToolStripMenuItem";
            this.tagToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.tagToolStripMenuItem.Text = "Tag Force 4";
            // 
            // uSAToolStripMenuItem
            // 
            this.uSAToolStripMenuItem.Name = "uSAToolStripMenuItem";
            this.uSAToolStripMenuItem.Size = new System.Drawing.Size(104, 22);
            this.uSAToolStripMenuItem.Text = "USA";
            this.uSAToolStripMenuItem.Click += new System.EventHandler(this.uSAToolStripMenuItem_Click);
            // 
            // jpanToolStripMenuItem
            // 
            this.jpanToolStripMenuItem.Name = "jpanToolStripMenuItem";
            this.jpanToolStripMenuItem.Size = new System.Drawing.Size(104, 22);
            this.jpanToolStripMenuItem.Text = "Japan";
            this.jpanToolStripMenuItem.Click += new System.EventHandler(this.jpanToolStripMenuItem_Click);
            // 
            // importarPacotesToolStripMenuItem
            // 
            this.importarPacotesToolStripMenuItem.Name = "importarPacotesToolStripMenuItem";
            this.importarPacotesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.importarPacotesToolStripMenuItem.Text = "Importar pacotes";
            this.importarPacotesToolStripMenuItem.Click += new System.EventHandler(this.importarPacotesToolStripMenuItem_Click);
            // 
            // sPSoundPackageToolStripMenuItem
            // 
            this.sPSoundPackageToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportarToolStripMenuItem2,
            this.sPRenamerToolStripMenuItem});
            this.sPSoundPackageToolStripMenuItem.Enabled = false;
            this.sPSoundPackageToolStripMenuItem.Name = "sPSoundPackageToolStripMenuItem";
            this.sPSoundPackageToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.sPSoundPackageToolStripMenuItem.Text = "SP (Sound Package )";
            this.sPSoundPackageToolStripMenuItem.Visible = false;
            // 
            // exportarToolStripMenuItem2
            // 
            this.exportarToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ùnicoToolStripMenuItem,
            this.loteToolStripMenuItem});
            this.exportarToolStripMenuItem2.Name = "exportarToolStripMenuItem2";
            this.exportarToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.exportarToolStripMenuItem2.Text = "Exportar";
            // 
            // ùnicoToolStripMenuItem
            // 
            this.ùnicoToolStripMenuItem.Name = "ùnicoToolStripMenuItem";
            this.ùnicoToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.ùnicoToolStripMenuItem.Text = "Único";
            this.ùnicoToolStripMenuItem.Click += new System.EventHandler(this.unicoToolStripMenuItem_Click);
            // 
            // loteToolStripMenuItem
            // 
            this.loteToolStripMenuItem.Name = "loteToolStripMenuItem";
            this.loteToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.loteToolStripMenuItem.Text = "Lote";
            this.loteToolStripMenuItem.Click += new System.EventHandler(this.loteToolStripMenuItem_Click);
            // 
            // sPRenamerToolStripMenuItem
            // 
            this.sPRenamerToolStripMenuItem.Enabled = false;
            this.sPRenamerToolStripMenuItem.Name = "sPRenamerToolStripMenuItem";
            this.sPRenamerToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sPRenamerToolStripMenuItem.Text = "SP Renamer";
            this.sPRenamerToolStripMenuItem.Visible = false;
            this.sPRenamerToolStripMenuItem.Click += new System.EventHandler(this.sPRenamerToolStripMenuItem_Click);
            // 
            // lBARecalcToolStripMenuItem
            // 
            this.lBARecalcToolStripMenuItem.Enabled = false;
            this.lBARecalcToolStripMenuItem.Name = "lBARecalcToolStripMenuItem";
            this.lBARecalcToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.lBARecalcToolStripMenuItem.Text = "LBA Recalc";
            this.lBARecalcToolStripMenuItem.Visible = false;
            this.lBARecalcToolStripMenuItem.Click += new System.EventHandler(this.lBARecalcToolStripMenuItem_Click);
            // 
            // textoTSM
            // 
            this.textoTSM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tagForceToolStripMenuItem2,
            this.previewTagForceToolStripMenuItem,
            this.cardSortEditorToolStripMenuItem});
            this.textoTSM.Name = "textoTSM";
            this.textoTSM.Size = new System.Drawing.Size(52, 20);
            this.textoTSM.Text = "Textos";
            // 
            // tagForceToolStripMenuItem2
            // 
            this.tagForceToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.extrairToolStripMenuItem,
            this.importarTextosToolStripMenuItem});
            this.tagForceToolStripMenuItem2.Name = "tagForceToolStripMenuItem2";
            this.tagForceToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.tagForceToolStripMenuItem2.Text = "Tag Force";
            // 
            // extrairToolStripMenuItem
            // 
            this.extrairToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.poneirosInternosToolStripMenuItem,
            this.ponteirosInternosDiretosToolStripMenuItem,
            this.ponteirosExternosToolStripMenuItem1,
            this.ponteirosTipo4ToolStripMenuItem,
            this.cardInfoToolStripMenuItem});
            this.extrairToolStripMenuItem.Name = "extrairToolStripMenuItem";
            this.extrairToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.extrairToolStripMenuItem.Text = "Exportar Textos";
            // 
            // poneirosInternosToolStripMenuItem
            // 
            this.poneirosInternosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.únicoToolStripMenuItem,
            this.emLoteToolStripMenuItem});
            this.poneirosInternosToolStripMenuItem.Name = "poneirosInternosToolStripMenuItem";
            this.poneirosInternosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.poneirosInternosToolStripMenuItem.Text = "Ponteiros tipo 1";
            // 
            // únicoToolStripMenuItem
            // 
            this.únicoToolStripMenuItem.Name = "únicoToolStripMenuItem";
            this.únicoToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.únicoToolStripMenuItem.Text = "strtbl/ msg / res / stbl";
            this.únicoToolStripMenuItem.Click += new System.EventHandler(this.únicoToolStripMenuItem_Click);
            // 
            // emLoteToolStripMenuItem
            // 
            this.emLoteToolStripMenuItem.Name = "emLoteToolStripMenuItem";
            this.emLoteToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.emLoteToolStripMenuItem.Text = "Lote";
            this.emLoteToolStripMenuItem.Click += new System.EventHandler(this.emLoteToolStripMenuItem_Click);
            // 
            // ponteirosInternosDiretosToolStripMenuItem
            // 
            this.ponteirosInternosDiretosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.únicoToolStripMenuItem1,
            this.loteeToolStripMenuItem});
            this.ponteirosInternosDiretosToolStripMenuItem.Name = "ponteirosInternosDiretosToolStripMenuItem";
            this.ponteirosInternosDiretosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ponteirosInternosDiretosToolStripMenuItem.Text = "Ponteiros tipo 2";
            // 
            // únicoToolStripMenuItem1
            // 
            this.únicoToolStripMenuItem1.Name = "únicoToolStripMenuItem1";
            this.únicoToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.únicoToolStripMenuItem1.Text = "tuto_text";
            this.únicoToolStripMenuItem1.Click += new System.EventHandler(this.únicoToolStripMenuItem1_Click);
            // 
            // loteeToolStripMenuItem
            // 
            this.loteeToolStripMenuItem.Name = "loteeToolStripMenuItem";
            this.loteeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.loteeToolStripMenuItem.Text = "De Pasta / Vários";
            this.loteeToolStripMenuItem.Click += new System.EventHandler(this.loteeToolStripMenuItem_Click);
            // 
            // ponteirosExternosToolStripMenuItem1
            // 
            this.ponteirosExternosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.únicoToolStripMenuItem2,
            this.dLGToolStripMenuItem});
            this.ponteirosExternosToolStripMenuItem1.Name = "ponteirosExternosToolStripMenuItem1";
            this.ponteirosExternosToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.ponteirosExternosToolStripMenuItem1.Text = "Ponteiros tipo 3";
            // 
            // únicoToolStripMenuItem2
            // 
            this.únicoToolStripMenuItem2.Name = "únicoToolStripMenuItem2";
            this.únicoToolStripMenuItem2.Size = new System.Drawing.Size(246, 22);
            this.únicoToolStripMenuItem2.Text = "Story_Scr \\ EveLe \\ SysMsgLe.bin";
            this.únicoToolStripMenuItem2.Click += new System.EventHandler(this.únicoToolStripMenuItem2_Click);
            // 
            // dLGToolStripMenuItem
            // 
            this.dLGToolStripMenuItem.Name = "dLGToolStripMenuItem";
            this.dLGToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.dLGToolStripMenuItem.Text = "DLG";
            this.dLGToolStripMenuItem.Click += new System.EventHandler(this.dLGToolStripMenuItem_Click);
            // 
            // ponteirosTipo4ToolStripMenuItem
            // 
            this.ponteirosTipo4ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.packstrExplainToolStripMenuItem});
            this.ponteirosTipo4ToolStripMenuItem.Name = "ponteirosTipo4ToolStripMenuItem";
            this.ponteirosTipo4ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ponteirosTipo4ToolStripMenuItem.Text = "Ponteiros tipo 4";
            // 
            // packstrExplainToolStripMenuItem
            // 
            this.packstrExplainToolStripMenuItem.Name = "packstrExplainToolStripMenuItem";
            this.packstrExplainToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.packstrExplainToolStripMenuItem.Text = "pack_str/ Explain";
            this.packstrExplainToolStripMenuItem.Click += new System.EventHandler(this.packstrExplainToolStripMenuItem_Click);
            // 
            // cardInfoToolStripMenuItem
            // 
            this.cardInfoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.únicoToolStripMenuItem3,
            this.pastaCardinfoTag4ToolStripMenuItem,
            this.pastaCardinfoTag6ToolStripMenuItem});
            this.cardInfoToolStripMenuItem.Name = "cardInfoToolStripMenuItem";
            this.cardInfoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cardInfoToolStripMenuItem.Text = "Card_Info";
            this.cardInfoToolStripMenuItem.Click += new System.EventHandler(this.cardInfoToolStripMenuItem_Click);
            // 
            // únicoToolStripMenuItem3
            // 
            this.únicoToolStripMenuItem3.Name = "únicoToolStripMenuItem3";
            this.únicoToolStripMenuItem3.Size = new System.Drawing.Size(197, 22);
            this.únicoToolStripMenuItem3.Text = "Pasta Card_info 2/3";
            this.únicoToolStripMenuItem3.Click += new System.EventHandler(this.únicoToolStripMenuItem3_Click);
            // 
            // pastaCardinfoTag4ToolStripMenuItem
            // 
            this.pastaCardinfoTag4ToolStripMenuItem.Name = "pastaCardinfoTag4ToolStripMenuItem";
            this.pastaCardinfoTag4ToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.pastaCardinfoTag4ToolStripMenuItem.Text = "Pasta Card_info Tag 4/5";
            this.pastaCardinfoTag4ToolStripMenuItem.Click += new System.EventHandler(this.pastaCardinfoTag4ToolStripMenuItem_Click_1);
            // 
            // pastaCardinfoTag6ToolStripMenuItem
            // 
            this.pastaCardinfoTag6ToolStripMenuItem.Name = "pastaCardinfoTag6ToolStripMenuItem";
            this.pastaCardinfoTag6ToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.pastaCardinfoTag6ToolStripMenuItem.Text = "Pasta Card_info Tag 6/S";
            this.pastaCardinfoTag6ToolStripMenuItem.Click += new System.EventHandler(this.pastaCardinfoTag6ToolStripMenuItem_Click);
            // 
            // importarTextosToolStripMenuItem
            // 
            this.importarTextosToolStripMenuItem.Name = "importarTextosToolStripMenuItem";
            this.importarTextosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.importarTextosToolStripMenuItem.Text = "Importar Textos";
            this.importarTextosToolStripMenuItem.Click += new System.EventHandler(this.importarTextosToolStripMenuItem_Click);
            // 
            // previewTagForceToolStripMenuItem
            // 
            this.previewTagForceToolStripMenuItem.Enabled = false;
            this.previewTagForceToolStripMenuItem.Name = "previewTagForceToolStripMenuItem";
            this.previewTagForceToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.previewTagForceToolStripMenuItem.Text = "Previewer Tag Force";
            this.previewTagForceToolStripMenuItem.Visible = false;
            this.previewTagForceToolStripMenuItem.Click += new System.EventHandler(this.previewTagForceToolStripMenuItem_Click);
            // 
            // cardSortEditorToolStripMenuItem
            // 
            this.cardSortEditorToolStripMenuItem.Name = "cardSortEditorToolStripMenuItem";
            this.cardSortEditorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cardSortEditorToolStripMenuItem.Text = "Editor de Card_Sort";
            this.cardSortEditorToolStripMenuItem.Click += new System.EventHandler(this.cardSortEditorToolStripMenuItem_Click);
            // 
            // imagensTSM
            // 
            this.imagensTSM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tagForceToolStripMenuItem1});
            this.imagensTSM.Name = "imagensTSM";
            this.imagensTSM.Size = new System.Drawing.Size(64, 20);
            this.imagensTSM.Text = "Imagens";
            // 
            // tagForceToolStripMenuItem1
            // 
            this.tagForceToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gimToolStripMenuItem,
            this.ediToolStripMenuItem});
            this.tagForceToolStripMenuItem1.Name = "tagForceToolStripMenuItem1";
            this.tagForceToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.tagForceToolStripMenuItem1.Text = "Tag Force";
            // 
            // gimToolStripMenuItem
            // 
            this.gimToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportarToolStripMenuItem,
            this.importarToolStripMenuItem});
            this.gimToolStripMenuItem.Name = "gimToolStripMenuItem";
            this.gimToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.gimToolStripMenuItem.Text = "Gim";
            // 
            // exportarToolStripMenuItem
            // 
            this.exportarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.únicoToolStripMenuItem4,
            this.emLoteDePastaToolStripMenuItem});
            this.exportarToolStripMenuItem.Name = "exportarToolStripMenuItem";
            this.exportarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exportarToolStripMenuItem.Text = "Exportar";
            // 
            // únicoToolStripMenuItem4
            // 
            this.únicoToolStripMenuItem4.Name = "únicoToolStripMenuItem4";
            this.únicoToolStripMenuItem4.Size = new System.Drawing.Size(180, 22);
            this.únicoToolStripMenuItem4.Text = "Único";
            this.únicoToolStripMenuItem4.Click += new System.EventHandler(this.únicoToolStripMenuItem4_Click);
            // 
            // emLoteDePastaToolStripMenuItem
            // 
            this.emLoteDePastaToolStripMenuItem.Name = "emLoteDePastaToolStripMenuItem";
            this.emLoteDePastaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.emLoteDePastaToolStripMenuItem.Text = "Em Lote";
            this.emLoteDePastaToolStripMenuItem.Click += new System.EventHandler(this.emLoteDePastaToolStripMenuItem_Click);
            // 
            // importarToolStripMenuItem
            // 
            this.importarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.únicoToolStripMenuItem5,
            this.emLoteDePastaToolStripMenuItem1});
            this.importarToolStripMenuItem.Name = "importarToolStripMenuItem";
            this.importarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.importarToolStripMenuItem.Text = "Importar";
            // 
            // únicoToolStripMenuItem5
            // 
            this.únicoToolStripMenuItem5.Name = "únicoToolStripMenuItem5";
            this.únicoToolStripMenuItem5.Size = new System.Drawing.Size(180, 22);
            this.únicoToolStripMenuItem5.Text = "Único";
            this.únicoToolStripMenuItem5.Click += new System.EventHandler(this.únicoToolStripMenuItem5_Click);
            // 
            // emLoteDePastaToolStripMenuItem1
            // 
            this.emLoteDePastaToolStripMenuItem1.Name = "emLoteDePastaToolStripMenuItem1";
            this.emLoteDePastaToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.emLoteDePastaToolStripMenuItem1.Text = "Em Lote";
            this.emLoteDePastaToolStripMenuItem1.Click += new System.EventHandler(this.emLoteDePastaToolStripMenuItem1_Click);
            // 
            // ediToolStripMenuItem
            // 
            this.ediToolStripMenuItem.Name = "ediToolStripMenuItem";
            this.ediToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.ediToolStripMenuItem.Text = "Editor de Nome De Cartas Card_h";
            this.ediToolStripMenuItem.Click += new System.EventHandler(this.ediToolStripMenuItem_Click);
            // 
            // compressãoTSM
            // 
            this.compressãoTSM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gzipToolStripMenuItem});
            this.compressãoTSM.Name = "compressãoTSM";
            this.compressãoTSM.Size = new System.Drawing.Size(85, 20);
            this.compressãoTSM.Text = "Compressão";
            // 
            // gzipToolStripMenuItem
            // 
            this.gzipToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gZIPToolStripMenuItem1});
            this.gzipToolStripMenuItem.Name = "gzipToolStripMenuItem";
            this.gzipToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gzipToolStripMenuItem.Text = "Tag Force 1";
            // 
            // gZIPToolStripMenuItem1
            // 
            this.gZIPToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.descomprimirToolStripMenuItem,
            this.comprimirToolStripMenuItem2});
            this.gZIPToolStripMenuItem1.Name = "gZIPToolStripMenuItem1";
            this.gZIPToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.gZIPToolStripMenuItem1.Text = "Gzip";
            // 
            // descomprimirToolStripMenuItem
            // 
            this.descomprimirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.únicoToolStripMenuItem6,
            this.emLoteToolStripMenuItem1});
            this.descomprimirToolStripMenuItem.Name = "descomprimirToolStripMenuItem";
            this.descomprimirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.descomprimirToolStripMenuItem.Text = "Descomprimir";
            // 
            // únicoToolStripMenuItem6
            // 
            this.únicoToolStripMenuItem6.Name = "únicoToolStripMenuItem6";
            this.únicoToolStripMenuItem6.Size = new System.Drawing.Size(180, 22);
            this.únicoToolStripMenuItem6.Text = "Único";
            this.únicoToolStripMenuItem6.Click += new System.EventHandler(this.únicoToolStripMenuItem6_Click);
            // 
            // emLoteToolStripMenuItem1
            // 
            this.emLoteToolStripMenuItem1.Name = "emLoteToolStripMenuItem1";
            this.emLoteToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.emLoteToolStripMenuItem1.Text = "Em Lote";
            this.emLoteToolStripMenuItem1.Click += new System.EventHandler(this.emLoteToolStripMenuItem1_Click);
            // 
            // comprimirToolStripMenuItem2
            // 
            this.comprimirToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.únicoToolStripMenuItem7,
            this.emLoteToolStripMenuItem2});
            this.comprimirToolStripMenuItem2.Name = "comprimirToolStripMenuItem2";
            this.comprimirToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.comprimirToolStripMenuItem2.Text = "Comprimir";
            // 
            // únicoToolStripMenuItem7
            // 
            this.únicoToolStripMenuItem7.Name = "únicoToolStripMenuItem7";
            this.únicoToolStripMenuItem7.Size = new System.Drawing.Size(180, 22);
            this.únicoToolStripMenuItem7.Text = "Único";
            this.únicoToolStripMenuItem7.Click += new System.EventHandler(this.únicoToolStripMenuItem7_Click);
            // 
            // emLoteToolStripMenuItem2
            // 
            this.emLoteToolStripMenuItem2.Name = "emLoteToolStripMenuItem2";
            this.emLoteToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.emLoteToolStripMenuItem2.Text = "Em Lote";
            this.emLoteToolStripMenuItem2.Click += new System.EventHandler(this.emLoteToolStripMenuItem2_Click);
            // 
            // ajudaTSM
            // 
            this.ajudaTSM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ajudaToolStripMenuItem});
            this.ajudaTSM.Name = "ajudaTSM";
            this.ajudaTSM.Size = new System.Drawing.Size(50, 20);
            this.ajudaTSM.Text = "Ajuda";
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ajudaToolStripMenuItem.Text = "Sobre";
            this.ajudaToolStripMenuItem.Click += new System.EventHandler(this.ajudaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 20);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivosTSM,
            this.textoTSM,
            this.imagensTSM,
            this.compressãoTSM,
            this.ajudaTSM,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(344, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // progressBarGimConv
            // 
            this.progressBarGimConv.Location = new System.Drawing.Point(12, 29);
            this.progressBarGimConv.Name = "progressBarGimConv";
            this.progressBarGimConv.Size = new System.Drawing.Size(191, 23);
            this.progressBarGimConv.TabIndex = 1;
            this.progressBarGimConv.Visible = false;
            // 
            // labelGimComv
            // 
            this.labelGimComv.AutoSize = true;
            this.labelGimComv.Location = new System.Drawing.Point(76, 13);
            this.labelGimComv.Name = "labelGimComv";
            this.labelGimComv.Size = new System.Drawing.Size(0, 13);
            this.labelGimComv.TabIndex = 2;
            this.labelGimComv.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.progressBarGimConv);
            this.panel1.Controls.Add(this.labelGimComv);
            this.panel1.Location = new System.Drawing.Point(71, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(218, 72);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 14F);
            this.label1.Location = new System.Drawing.Point(148, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Status";
            // 
            // TelaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 153);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(360, 192);
            this.MinimumSize = new System.Drawing.Size(360, 192);
            this.Name = "TelaPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "YGTool";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem arquivosTSM;
        private System.Windows.Forms.ToolStripMenuItem tagForceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eHPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportarÚnicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportarDePastaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarÚnicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarEmLoteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bootbinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textoTSM;
        private System.Windows.Forms.ToolStripMenuItem tagForceToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem extrairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poneirosInternosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem únicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem emLoteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ponteirosInternosDiretosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem únicoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem loteeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ponteirosExternosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem únicoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem dLGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cardInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem únicoToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem importarTextosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem previewTagForceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imagensTSM;
        private System.Windows.Forms.ToolStripMenuItem tagForceToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem únicoToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem emLoteDePastaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem únicoToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem emLoteDePastaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem compressãoTSM;
        private System.Windows.Forms.ToolStripMenuItem gzipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajudaTSM;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportarGIMToolStripMenuItem;
        private System.Windows.Forms.ProgressBar progressBarGimConv;
        private System.Windows.Forms.Label labelGimComv;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem importarGimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ediToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tARGFORCE2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportarEhpsNoEBBOTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarEhpsNoEBOOTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gZIPToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem descomprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem únicoToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem emLoteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem comprimirToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem únicoToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem emLoteToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem sndDatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sPSoundPackageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ùnicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarPacotesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tagForce4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tagToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ponteirosTipo4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem packstrExplainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem europeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem japanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sPRenamerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jpanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lBARecalcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cardSortEditorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pastaCardinfoTag4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pastaCardinfoTag6ToolStripMenuItem;
    }
}

